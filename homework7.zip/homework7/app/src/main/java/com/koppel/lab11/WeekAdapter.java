package com.koppel.lab11;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.textfield.TextInputEditText;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class WeekAdapter extends RecyclerView.Adapter<WeekAdapter.WeekViewHolder> {

    private ArrayList<WeekDay> dayList;


    public WeekAdapter() { this.dayList = new ArrayList<>(); }

    @NonNull
    @Override
    public WeekViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_week,parent,false);
        return new WeekViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WeekAdapter.WeekViewHolder holder, int position) {

        WeekDay weekDay  = dayList.get(position);
        holder.info.setText(weekDay.getInfo());
        holder.dayTemperature.setText("During the day " + weekDay.getDayTemp()+" C");
        holder.nightTemperature.setText("At night "+weekDay.getNightTemp()+" C");
        holder.humidityAndSpeed.setText("Wind speed " + weekDay.getSpeed()+" m/s Humidity "+weekDay.getHumidity()+" %");
        holder.description.setText(weekDay.getDescription());
        Picasso.get().load(weekDay.getIcon()).resize(278,278).into(holder.icon);

    }

    @Override
    public int getItemCount() {
        return dayList.size();
    }

    public void setDayList(final ArrayList<WeekDay> dayList) {this.dayList = dayList; notifyDataSetChanged();}

    static class WeekViewHolder extends RecyclerView.ViewHolder{
        private final TextView info;
        private final TextView dayTemperature;
        private final TextView nightTemperature;
        private final TextView description;
        private final TextView humidityAndSpeed;
        private final ImageView icon;

        public WeekViewHolder(@NonNull View itemView) {
            super(itemView);
            info = itemView.findViewById(R.id.txtWeekDate);
            dayTemperature = itemView.findViewById(R.id.txtWeekDayTemp);
            nightTemperature = itemView.findViewById(R.id.txtWeeknightTemp);
            description = itemView.findViewById(R.id.txtWeekDescription);
            humidityAndSpeed = itemView.findViewById(R.id.txtWeekWindAndHume);
            icon = itemView.findViewById(R.id.imgWeek);

        }
    }
}
