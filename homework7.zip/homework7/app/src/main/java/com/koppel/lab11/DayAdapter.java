package com.koppel.lab11;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.textfield.TextInputEditText;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class DayAdapter extends RecyclerView.Adapter<DayAdapter.DayViewHolder> {
    private ArrayList<Day> dayList;

    public DayAdapter() { this.dayList = new ArrayList<>(); }

    @NonNull
    @Override
    public DayViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_day,parent,false);
        return new DayViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DayViewHolder holder, int position) {
        Day day  = dayList.get(position);
        holder.info.setText(day.getInfo());
        holder.currentTemperature.setText(day.getCurrentTemp());
        holder.feelsTemperature.setText(day.getFeelTemp());
        holder.humidity.setText(day.getHumidity());
        holder.speed.setText(day.getSpeed());
        holder.sunrise.setText(day.getSunrise());
        holder.sunset.setText(day.getSunset());
        holder.description.setText(day.getDescription());
        Picasso.get().load(day.getIcon()).into(holder.icon);
        Bundle args = new Bundle();
        args.putString("lon",day.getLon());
        args.putString("lat",day.getLat());
        holder.button.setOnClickListener(
                Navigation.createNavigateOnClickListener(R.id.action_dayFragment_to_weekFragment,args)
        );

    }

    @Override
    public int getItemCount() {
        return dayList.size();
    }

    public void setDayList(final ArrayList<Day> dayList) {this.dayList = dayList; notifyDataSetChanged();}

    static class DayViewHolder extends RecyclerView.ViewHolder{
        private final TextInputEditText info;
        private final TextInputEditText currentTemperature;
        private final TextInputEditText feelsTemperature;
        private final TextInputEditText description;
        private final TextInputEditText humidity;
        private final TextInputEditText speed;
        private final TextInputEditText sunrise;
        private final TextInputEditText sunset;
        private final ImageView icon;
        private final Button button;

        public DayViewHolder(@NonNull View itemView) {
            super(itemView);
            info = itemView.findViewById(R.id.txtWeatherInfo);
            currentTemperature = itemView.findViewById(R.id.txtCurrentTemp);
            feelsTemperature = itemView.findViewById(R.id.txtFeelsTemp);
            description = itemView.findViewById(R.id.txtDescription);
            humidity = itemView.findViewById(R.id.txtHumidity);
            speed = itemView.findViewById(R.id.txtWindSpeed);
            sunrise = itemView.findViewById(R.id.txtSunrise);
            sunset = itemView.findViewById(R.id.txtSunset);
            icon = itemView.findViewById(R.id.imgWeatherIcon);
            button = itemView.findViewById(R.id.btnWeek);

        }
    }
}
