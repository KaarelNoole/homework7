package com.koppel.lab11;

import android.app.Application;
import android.util.Log;

import androidx.lifecycle.MutableLiveData;

import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import com.koushikdutta.ion.Ion;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class Repository {

    private static final String API_KEY ="b2f8837f133f27984ff703c194f1c413";
    private static final String URL="https://api.openweathermap.org/data/2.5/weather?q=%s&appid=%s&units=metric";
    private static final String URL2="https://api.openweathermap.org/data/2.5/onecall?lat=%s&lon=%s&exclude=hourly,current,minutely,alerts&appid=%s&units=metric";
    private final Application application;
    private final MutableLiveData<ArrayList<Day>> dayLiveData;
    private final ArrayList<Day> arrayList = new ArrayList<>();
    private final MutableLiveData<ArrayList<WeekDay>> weekDayLiveData;
    private final ArrayList<WeekDay> weekArrayList = new ArrayList<>();

    public Repository(Application application) {
        this.application = application;
        dayLiveData = new MutableLiveData<>();
        weekDayLiveData = new MutableLiveData<>();
    }

    public void getDayWeather(String city){
        Ion.with(application).load(String.format(URL,city,API_KEY)).asJsonObject()
                .setCallback((e, result) -> {
                    Log.i("getDayWeather: ", result.getAsJsonPrimitive("cod").toString());
                    parseResult(result);
                });
    }

    public void getWeekWeather(String lat, String lon){
        Ion.with(application).load(String.format(URL2,lat,lon,API_KEY)).asJsonObject()
                .setCallback((e, result) -> {
                    Log.i("tag", String.format(URL2,lat,lon,API_KEY));
                    parseResultWeek(result);
                });
    }

    private void parseResult(JsonObject result) {
        JsonObject details = (JsonObject) result.getAsJsonArray("weather").get(0);
        JsonObject main = result.getAsJsonObject("main");
        JsonObject sys = result.getAsJsonObject("sys");
        JsonObject wind = result.getAsJsonObject("wind");
        JsonPrimitive date = result.getAsJsonPrimitive("dt");
        JsonObject cords = result.getAsJsonObject("coord");

        String temp = convertTemp(main.get("temp").toString());
        String feels = convertTemp(main.get("feels_like").toString());
        String humidity = main.get("humidity").toString();
        String speed = convertTemp(wind.get("speed").toString());
        String description = String.valueOf(details.get("description")).toUpperCase(Locale.getDefault());
        String ic = details.get("icon").toString();
        String icon = "https://openweathermap.org/img/wn/"+ removeAbles(ic) + ".png";
        long updated = Long.parseLong(String.valueOf(date.getAsLong()));
        long sunrise = Long.parseLong(sys.get("sunrise").toString());
        long sunset = Long.parseLong(sys.get("sunset").toString());
        String lon = cords.get("lon").toString();
        String lat = cords.get("lat").toString();


        Day day = new Day(convertTime(updated),temp,feels,removeAbles(description),humidity,speed,convertTime(sunrise),convertTime(sunset),icon,lat,lon);
        arrayList.add(day);
        dayLiveData.setValue(arrayList);

    }

    private void parseResultWeek(JsonObject result) {
        for (int day =1; day<=7; day++ ) {
            JsonObject daily = (JsonObject) result.getAsJsonArray("daily").get(day);
            JsonObject details = (JsonObject) daily.getAsJsonArray("weather").get(0);
            JsonObject temp = daily.getAsJsonObject("temp");
            JsonPrimitive date = daily.getAsJsonPrimitive("dt");
            JsonPrimitive hume = daily.getAsJsonPrimitive("humidity");
            JsonPrimitive speeds = daily.getAsJsonPrimitive("wind_speed");


            String dayTemp = convertTemp(temp.get("day").toString());
            String nightTemp = convertTemp(temp.get("night").toString());
            String humidity = hume.toString();
            Log.i("TAG", hume.toString());
            Log.i("TAG", speeds.toString());
            String speed = speeds.toString();
            String description = String.valueOf(details.get("description")).toUpperCase(Locale.getDefault());
            String ic = details.get("icon").toString();
            String icon = "https://openweathermap.org/img/wn/"+ removeAbles(ic) + ".png";
            long updated = Long.parseLong(String.valueOf(date.getAsLong()));

            WeekDay WeekDay = new WeekDay(convertTime(updated),dayTemp,nightTemp,removeAbles(description),humidity,speed,icon);
            weekArrayList.add(WeekDay);
            weekDayLiveData.setValue(weekArrayList);
        }
    }

    public String convertTime(long time) {
        DateFormat dt = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.getDefault());
        return dt.format(new Date(time*1000));
    }

    public String convertTemp(String temp) {
        BigDecimal value = new BigDecimal(temp);
        value = value.setScale(0, RoundingMode.HALF_UP);
        return String.valueOf(value);
    }

    public String removeAbles(String text){return  text.substring(1,text.length()-1);}

    public MutableLiveData<ArrayList<Day>> getDayLiveData() {
        return dayLiveData;
    }

    public MutableLiveData<ArrayList<WeekDay>> getWeekDayLiveData() {
        return weekDayLiveData;
    }

}
