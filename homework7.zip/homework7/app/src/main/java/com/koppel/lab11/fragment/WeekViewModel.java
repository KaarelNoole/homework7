package com.koppel.lab11.fragment;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.koppel.lab11.Day;
import com.koppel.lab11.Repository;
import com.koppel.lab11.WeekDay;

import java.util.ArrayList;

public class WeekViewModel extends AndroidViewModel {
    private final Repository repository;
    private final MutableLiveData<ArrayList<WeekDay>> weekDayLiveData;


    public WeekViewModel(@NonNull Application application) {
        super(application);
        repository = new Repository(application);
        weekDayLiveData = repository.getWeekDayLiveData();

    }

    public MutableLiveData<ArrayList<WeekDay>> getWeekDayLiveData() {
        return weekDayLiveData;
    }

    public void getWeekWeather(String lat,String lon){repository.getWeekWeather(lat,lon);}
}